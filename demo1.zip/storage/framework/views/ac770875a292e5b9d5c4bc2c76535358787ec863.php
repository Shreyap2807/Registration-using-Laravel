<h1>Login</h1>
<?php /**PATH C:\xampp1\htdocs\WDLEXP\demo1\resources\views/login/login.blade.php ENDPATH**/ ?>